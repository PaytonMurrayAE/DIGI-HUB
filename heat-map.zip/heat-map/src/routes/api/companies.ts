import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";

import { getBaseCompanies } from "@/lib/base-companies.server";
import { getGateSession } from "@/lib/gate.server";
import { COMPANIES_ROW_ID, getSupabaseAdmin } from "@/lib/supabase.server";

const putSchema = z.object({
  payload: z.array(z.unknown()),
  version: z.number().int().nonnegative(),
});

export const Route = createFileRoute("/api/companies")({
  server: {
    handlers: {
      GET: async () => {
        const session = await getGateSession();
        if (!session.data.unlocked) {
          return new Response("Locked", { status: 401 });
        }

        const supabase = await getSupabaseAdmin();
        const { data, error } = await supabase
          .from("territory_state")
          .select("payload, version")
          .eq("id", COMPANIES_ROW_ID)
          .single();

        if (error) {
          console.error(
            "GET /api/companies failed:",
            error.message,
            "cause:",
            (error as { cause?: unknown }).cause,
          );
          return Response.json({ error: "Failed to read companies" }, { status: 500 });
        }

        // Auto-seed the shared store when it is empty — regardless of version.
        // The heat map's client-side self-seed is unreliable when the embed
        // iframe lacks the unlocked session cookie, so the spreadsheet (which
        // only reads this store) would otherwise show nothing. Seeding
        // server-side from the identical base list makes both views agree.
        // The .eq("version", data.version) guard preserves the
        // optimistic-concurrency contract: a concurrent write wins, and we
        // just re-read the result.
        if (Array.isArray(data.payload) && data.payload.length === 0) {
          const base = getBaseCompanies();
          const { data: seeded, error: seedError } = await supabase
            .from("territory_state")
            .update({
              payload: base,
              version: Number(data.version) + 1,
              updated_at: new Date().toISOString(),
              updated_by: "system-seed",
            })
            .eq("id", COMPANIES_ROW_ID)
            .eq("version", Number(data.version))
            .select("payload, version")
            .single();

          if (seedError && seedError.code === "PGRST116") {
            const current = await fetchCurrent(supabase);
            return Response.json(current);
          }
          if (seedError) {
            console.error("GET /api/companies seed failed:", seedError.message);
            return Response.json({ error: "Failed to seed companies" }, { status: 500 });
          }
          return Response.json({ payload: seeded.payload, version: seeded.version });
        }

        return Response.json({ payload: data.payload, version: data.version });
      },

      PUT: async ({ request }) => {
        const session = await getGateSession();
        if (!session.data.unlocked) {
          return new Response("Locked", { status: 401 });
        }

        let json: unknown;
        try {
          json = await request.json();
        } catch {
          return Response.json({ error: "Invalid JSON body" }, { status: 400 });
        }

        const parsed = putSchema.safeParse(json);
        if (!parsed.success) {
          return Response.json(
            { error: "Invalid body", issues: parsed.error.issues },
            { status: 400 },
          );
        }

        const { payload, version } = parsed.data;
        const supabase = await getSupabaseAdmin();

        // Optimistic-concurrency write: only update if the stored version still
        // matches the client's. If another save landed in between, affected
        // rows = 0 and we return the current state with 409.
        const { data: updated, error } = await supabase
          .from("territory_state")
          .update({
            payload,
            version: version + 1,
            updated_at: new Date().toISOString(),
            updated_by: session.data.name ?? null,
          })
          .eq("id", COMPANIES_ROW_ID)
          .eq("version", version)
          .select("payload, version")
          .single();

        if (error) {
          // A uniqueness/row miss surfaces as a PostgREST error (no row matched
          // the WHERE clause). Treat that as a stale-version conflict.
          if (error.code === "PGRST116") {
            const current = await fetchCurrent(supabase);
            return Response.json(current, { status: 409 });
          }
          console.error("PUT /api/companies failed:", error.message);
          return Response.json({ error: "Failed to save companies" }, { status: 500 });
        }

        return Response.json({ payload: updated.payload, version: updated.version });
      },
    },
  },
});

async function fetchCurrent(supabase: Awaited<ReturnType<typeof getSupabaseAdmin>>) {
  const { data } = await supabase
    .from("territory_state")
    .select("payload, version")
    .eq("id", COMPANIES_ROW_ID)
    .single();
  return { payload: data?.payload ?? [], version: data?.version ?? 0 };
}
