import { createFileRoute } from "@tanstack/react-router";

import { getGateSession } from "@/lib/gate.server";

// Gated, keyless Census Reporter proxy.
//
// Fetches ACS table B01001 (sex-by-age) for every US county server-side,
// computes an estimated 55-65 population per county, and returns a compact
// { fips -> { age55_65, total, pct } } map. The browser never calls
// Census Reporter directly — this route is the only path, and it inherits
// the same password gate as the embed route.
//
// The 55-65 bracket is estimated: Census publishes exact 55-64 buckets plus a
// 65-66 bracket. We take the full 55-64 count and add half of 65-66 (one year
// out of the two-year bracket) to approximate age 65.
//
// In-memory cache: ACS 5-year estimates change rarely, so we cache the
// processed result for 24h within the Worker isolate. A redeploy simply
// re-fetches once.

type CountyAge = { age55_65: number; total: number; pct: number };
type AgeMap = Record<string, CountyAge>;

let cache: { at: number; data: AgeMap } | null = null;
const CACHE_TTL_MS = 1000 * 60 * 60 * 24; // 24 hours

export const Route = createFileRoute("/api/census/age")({
  server: {
    handlers: {
      GET: async () => {
        const session = await getGateSession();
        if (!session.data.unlocked) {
          return new Response("Locked", { status: 401 });
        }

        if (cache && Date.now() - cache.at < CACHE_TTL_MS) {
          return Response.json(cache.data, {
            headers: { "cache-control": "public, max-age=86400" },
          });
        }

        try {
          const res = await fetch(
            "https://api.censusreporter.org/1.0/data/show/latest?table_ids=B01001&geo_ids=050|01000US",
            {
              headers: {
                "User-Agent": "AEDigiMap/1.0 (territory-map)",
                Accept: "application/json",
              },
            },
          );
          if (!res.ok) {
            console.error("Census Reporter HTTP", res.status);
            return Response.json({ error: "Census API unavailable" }, { status: 502 });
          }

          const json = (await res.json()) as {
            data: Record<string, { B01001?: { estimate: Record<string, number> } }>;
          };

          const get = (est: Record<string, number>, key: string): number =>
            typeof est[key] === "number" ? est[key] : 0;

          const counties: AgeMap = {};
          for (const geoId of Object.keys(json.data)) {
            if (!geoId.startsWith("05000US")) continue;
            const fips = geoId.slice(7); // "05000US01001" -> "01001"
            const est = json.data[geoId]?.B01001?.estimate;
            if (!est) continue;

            // Male: 55-59=B01001017, 60-61=B01001018, 62-64=B01001019, 65-66=B01001020
            // Female: 55-59=B01001041, 60-61=B01001042, 62-64=B01001043, 65-66=B01001044
            const m55_64 = get(est, "B01001017") + get(est, "B01001018") + get(est, "B01001019");
            const f55_64 = get(est, "B01001041") + get(est, "B01001042") + get(est, "B01001043");
            const over65 = get(est, "B01001020") + get(est, "B01001044"); // 65-66 bracket (2 yrs)

            const age55_65 = Math.round(m55_64 + f55_64 + over65 / 2);
            const total = get(est, "B01001001");
            counties[fips] = {
              age55_65,
              total,
              pct: total ? Math.round((age55_65 / total) * 1000) / 10 : 0,
            };
          }

          cache = { at: Date.now(), data: counties };
          return Response.json(counties, {
            headers: { "cache-control": "public, max-age=86400" },
          });
        } catch (err) {
          console.error("Census fetch failed:", err);
          return Response.json({ error: "Failed to fetch census data" }, { status: 502 });
        }
      },
    },
  },
});
