import { createFileRoute, useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { ExternalLink, FileCode2, Table2 } from "lucide-react";
import { useEffect, useState } from "react";

import { AeLogo } from "@/components/ae-logo";
import { Button } from "@/components/ui/button";
import { SpreadsheetView } from "@/components/spreadsheet-view";
import { getReview, lockSite } from "@/lib/gate.functions";

export const Route = createFileRoute("/")({
  // Still gated: getReview() calls requireUnlocked() and redirects to /unlock
  // when there is no session. We keep the loader purely as the auth gate.
  loader: () => getReview(),
  head: () => ({
    meta: [
      { title: "AE Digi Map — Territory Map" },
      {
        name: "description",
        content:
          "Password-protected AE Digi Map — territory map and client intake pages, shared with the team.",
      },
      { property: "og:title", content: "AE Digi Map" },
      {
        property: "og:description",
        content: "Password-protected AE Digi Map territory map and client intake.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: Map,
});

const PAGES = [
  { key: "territory-map", label: "Territory Map" },
  { key: "client-intake", label: "Client Intake" },
] as const;

const EMBED_VERSION = "2026-10-15-jump-to-v10";

function Map() {
  const initial = Route.useLoaderData();
  const router = useRouter();
  const signOut = useServerFn(lockSite);

  const [page, setPage] = useState<(typeof PAGES)[number]["key"]>("territory-map");
  // "map" = the embedded heat map iframe; "sheet" = the editable spreadsheet.
  // Switching back to "map" bumps `mapReloadKey` so the iframe re-GETs the
  // shared store and reflects spreadsheet edits.
  const [viewMode, setViewMode] = useState<"map" | "sheet">("map");
  const [mapReloadKey, setMapReloadKey] = useState(0);

  // The embedded heat map posts this message when its "Spreadsheet" button
  // (added next to "Export data") is clicked — switch to the editable view.
  useEffect(() => {
    function onMessage(e: MessageEvent) {
      if (e.data?.type === "aedigimap:open-spreadsheet") {
        setViewMode("sheet");
      }
    }
    window.addEventListener("message", onMessage);
    return () => window.removeEventListener("message", onMessage);
  }, []);

  async function onLock() {
    await signOut();
    await router.navigate({ to: "/unlock" });
  }

  return (
    <div
      className="dark relative min-h-screen bg-[#1a1a1c] bg-cover bg-center bg-no-repeat"
      style={{
        backgroundImage:
          "url('https://vibe.filesafe.space/1789407187340213449/attachments/87f918e5-4494-4dba-996f-8a850ed12f49.png')",
      }}
    >
      <header className="surface-deep border-b-4 border-transparent [border-image:var(--gradient-brand)_1]">
        <div className="mx-auto flex max-w-[1600px] flex-wrap items-center justify-between gap-4 px-6 py-5">
          <div className="flex items-center gap-4">
            <AeLogo variant="light" className="h-11 w-auto" />
            <div>
              <p className="font-display text-xs font-semibold uppercase tracking-[0.18em] opacity-70">
                AEDigital
              </p>
              <h1 className="text-xl font-semibold">Territory Map</h1>
            </div>
          </div>
          <div className="flex items-center gap-3 text-sm">
            <span className="opacity-80">Signed in as {initial.viewer}</span>
            <Button variant="secondary" size="sm" onClick={onLock}>
              Lock
            </Button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-[1600px] px-6 py-8">
        {viewMode === "sheet" ? (
          <SpreadsheetView
            onBackToMap={() => {
              setViewMode("map");
              // Bump the iframe key so it re-GETs the shared store and shows
              // whatever was just edited in the spreadsheet.
              setMapReloadKey((k) => k + 1);
            }}
          />
        ) : (
          <section className="panel overflow-hidden" aria-label="Uploaded webpage">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border px-5 py-3 text-sm">
              <div className="flex items-center gap-2 text-muted-foreground">
                <FileCode2 className="h-4 w-4" aria-hidden="true" />
                {PAGES.find((item) => item.key === page)?.label ?? "Uploaded webpage"}
              </div>
              <div className="flex items-center gap-2">
                {PAGES.map((item) => (
                  <Button
                    key={item.key}
                    size="sm"
                    variant={page === item.key ? "default" : "secondary"}
                    onClick={() => setPage(item.key)}
                  >
                    {item.label}
                  </Button>
                ))}
                <Button size="sm" variant="secondary" onClick={() => setViewMode("sheet")}>
                  <Table2 className="mr-1.5 h-4 w-4" aria-hidden="true" />
                  Spreadsheet
                </Button>
                <a
                  href={`/embed/${page}?v=${EMBED_VERSION}`}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1 text-xs font-medium text-muted-foreground underline-offset-4 hover:underline"
                >
                  <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
                  Full screen
                </a>
              </div>
            </div>
            <iframe
              key={`${page}-${mapReloadKey}`}
              src={`/embed/${page}?v=${EMBED_VERSION}`}
              title={PAGES.find((item) => item.key === page)?.label ?? "Uploaded webpage"}
              className="h-[88vh] min-h-[600px] w-full border-0 bg-white"
            />
          </section>
        )}
      </main>
    </div>
  );
}
