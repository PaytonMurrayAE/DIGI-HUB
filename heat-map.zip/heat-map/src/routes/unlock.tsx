import { createFileRoute, useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Lock } from "lucide-react";
import { useState } from "react";

import { AeLogo } from "@/components/ae-logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { unlockSite } from "@/lib/gate.functions";

export const Route = createFileRoute("/unlock")({
  head: () => ({
    meta: [
      { title: "AEDigital — Sign in" },
      {
        name: "description",
        content: "Enter your name and the team password to access the AEDigital territory map.",
      },
      { property: "og:title", content: "AEDigital — Sign in" },
      {
        property: "og:description",
        content: "Enter your name and the team password to access the AEDigital territory map.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: Unlock,
});

function Unlock() {
  const router = useRouter();
  const unlock = useServerFn(unlockSite);
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const name = String(form.get("name") ?? "").trim();
    const password = String(form.get("password") ?? "");

    if (!name) {
      setError("Please add your name so your comments are attributed.");
      return;
    }

    setPending(true);
    setError(null);
    try {
      const result = await unlock({ data: { name, password } });
      if (result.ok) {
        await router.navigate({ to: "/" });
      } else {
        setError("That password doesn't match. Check with the project owner.");
      }
    } catch {
      setError("Something went wrong. Please try again.");
    } finally {
      setPending(false);
    }
  }

  return (
    <main
      className="relative flex min-h-screen items-center justify-center px-4 py-16 bg-[#1a1a1c] bg-cover bg-center bg-no-repeat"
      style={{
        backgroundImage: `url('https://vibe.filesafe.space/1789407187340213449/attachments/87f918e5-4494-4dba-996f-8a850ed12f49.png')`,
      }}
    >
      <div className="panel relative z-10 w-full max-w-md overflow-hidden bg-card/95 shadow-2xl backdrop-blur-sm">
        <div className="bg-gradient-brand h-1.5 w-full" />
        <div className="p-8">
          <AeLogo variant="dark" className="mb-6 h-14 w-auto" />

          <p className="font-display inline-flex items-center gap-2 text-xs font-semibold tracking-[0.18em] text-muted-foreground">
            <Lock className="h-3.5 w-3.5" aria-hidden="true" />
            AEDigital
          </p>
          <h1 className="mt-2 text-2xl font-semibold">Sign in</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Enter your name and the team password to access the territory map.
          </p>

          <form onSubmit={onSubmit} className="mt-7 space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Your name</Label>
              <Input
                id="name"
                name="name"
                autoComplete="name"
                maxLength={60}
                placeholder="Jane Doe"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Team password</Label>
              <Input
                id="password"
                name="password"
                type="password"
                autoComplete="current-password"
                maxLength={200}
                placeholder="••••••••"
              />
            </div>

            {error ? (
              <p role="alert" className="text-sm text-destructive">
                {error}
              </p>
            ) : null}

            <Button type="submit" className="w-full" disabled={pending}>
              {pending ? "Checking…" : "Sign in"}
            </Button>
          </form>
        </div>
      </div>
    </main>
  );
}
