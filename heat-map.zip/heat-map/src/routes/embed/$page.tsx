import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/embed/$page")({
  server: {
    handlers: {
      GET: async ({ params }) => {
        const { getGateSession } = await import("@/lib/gate.server");
        const session = await getGateSession();
        if (!session.data.unlocked) {
          return new Response("Locked", { status: 401 });
        }

        const { UPLOADED_PAGES, isUploadedPageKey } = await import("@/lib/pages.server");
        const key = params.page;
        if (!isUploadedPageKey(key)) {
          return new Response("Not found", { status: 404 });
        }

        return new Response(UPLOADED_PAGES[key].html, {
          headers: {
            "content-type": "text/html; charset=utf-8",
            "cache-control": "no-store",
            "x-robots-tag": "noindex, nofollow",
          },
        });
      },
    },
  },
});
