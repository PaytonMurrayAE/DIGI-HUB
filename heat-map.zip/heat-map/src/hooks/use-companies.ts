// Shared, server-backed company list.
//
// The heat map iframe already GETs /api/companies on load and PUTs on save.
// This hook is the React-side equivalent for the spreadsheet view: it reads
// the same store, polls it so teammate edits appear within a few seconds, and
// writes back with optimistic-concurrency (PUT includes the version we read;
// a 409 means someone else saved first and we reload theirs instead of
// clobbering).

import { useCallback, useEffect, useRef, useState } from "react";

import type { Company } from "@/lib/companies.types";

export type CompaniesState = {
  data: Company[];
  version: number | null;
  loading: boolean;
  saving: boolean;
  /** Set briefly after a successful save, then cleared. */
  savedAt: number | null;
  /** Non-empty when the last save lost a race (someone else saved first). */
  conflict: string | null;
  /** Non-empty on network/auth errors. */
  error: string | null;
};

export type SaveResult =
  | { ok: true; data: Company[]; version: number }
  | { ok: false; conflict: true; data: Company[]; version: number }
  | { ok: false; conflict: false; error: string };

const POLL_MS = 5000;

export function useCompanies() {
  const [state, setState] = useState<CompaniesState>({
    data: [],
    version: null,
    loading: true,
    saving: false,
    savedAt: null,
    conflict: null,
    error: null,
  });

  // Keep the latest version in a ref so polling can compare without re-binding.
  const versionRef = useRef<number | null>(null);
  versionRef.current = state.version;

  const read = useCallback(async (): Promise<{ data: Company[]; version: number } | null> => {
    try {
      const res = await fetch("/api/companies", { cache: "no-store" });
      if (res.status === 401) return null;
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const body = (await res.json()) as { payload: Company[]; version: number };
      return { data: Array.isArray(body.payload) ? body.payload : [], version: body.version };
    } catch {
      return null;
    }
  }, []);

  // Initial load.
  useEffect(() => {
    let alive = true;
    read().then((res) => {
      if (!alive) return;
      setState((s) =>
        res
          ? { ...s, data: res.data, version: res.version, loading: false }
          : { ...s, loading: false, error: "Not unlocked — showing your browser's copy only." },
      );
    });
    return () => {
      alive = false;
    };
  }, [read]);

  // Poll for teammate changes. Only adopt a new payload when the server version
  // advanced beyond ours and we are not mid-save, so an unsaved local edit is
  // not silently overwritten.
  const savingRef = useRef(false);
  savingRef.current = state.saving;

  useEffect(() => {
    const id = setInterval(() => {
      if (savingRef.current) return;
      read().then((res) => {
        if (!res) return;
        if (state.saving) return;
        if (res.version !== versionRef.current) {
          setState((s) =>
            s.saving ? s : { ...s, data: res.data, version: res.version, savedAt: null },
          );
        }
      });
    }, POLL_MS);
    return () => clearInterval(id);
  }, [read, state.saving]);

  // Save with optimistic-concurrency. Returns the outcome so callers can
  // branch (e.g. prompt a retry on conflict). State is also updated for UI.
  const save = useCallback(
    async (next: Company[], baseVersion?: number): Promise<SaveResult> => {
      // baseVersion is the store version the caller's draft is based on. When
      // the user has unsaved edits and a teammate saved in between, the draft
      // is NOT reset (see SpreadsheetView), so we must PUT the version the
      // draft was built from — not the latest polled version — or a concurrent
      // save would be silently overwritten instead of surfacing a 409.
      const version = baseVersion ?? state.version;
      setState((s) => ({ ...s, saving: true, conflict: null, error: null }));
      try {
        const res = await fetch("/api/companies", {
          method: "PUT",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ payload: next, version }),
        });
        const body = (await res.json().catch(() => ({}))) as {
          payload?: Company[];
          version?: number;
          error?: string;
        };
        if (res.status === 200) {
          const data = Array.isArray(body.payload) ? body.payload : next;
          setState((s) => ({
            ...s,
            data,
            version: body.version ?? s.version,
            saving: false,
            savedAt: Date.now(),
          }));
          return { ok: true, data, version: body.version ?? state.version ?? 0 };
        }
        if (res.status === 409) {
          const data = Array.isArray(body.payload) ? body.payload : state.data;
          setState((s) => ({
            ...s,
            data,
            version: body.version ?? s.version,
            saving: false,
            conflict:
              "Someone else saved changes first. The sheet was refreshed with their version — re-apply your edit.",
          }));
          return {
            ok: false,
            conflict: true,
            data,
            version: body.version ?? state.version ?? 0,
          };
        }
        const msg =
          res.status === 401
            ? "Session expired — unlock the page again to save."
            : body.error || `Could not save (HTTP ${res.status}).`;
        setState((s) => ({ ...s, saving: false, error: msg }));
        return { ok: false, conflict: false, error: msg };
      } catch (e) {
        const msg = "Could not reach the server — your change is local only.";
        setState((s) => ({ ...s, saving: false, error: msg }));
        return { ok: false, conflict: false, error: msg };
      }
    },
    [state.version, state.data],
  );

  const dismissConflict = useCallback(() => setState((s) => ({ ...s, conflict: null })), []);

  return { ...state, save, dismissConflict, refresh: read };
}
