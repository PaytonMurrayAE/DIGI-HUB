import { createClient, type SupabaseClient } from "@supabase/supabase-js";

// Server-only Supabase client using the service-role key.
//
// This file ends in .server.ts so the import guard strips it from every
// client bundle. The service-role key bypasses RLS, which is required because
// the territory_state table has no anon/authenticated policies — every read
// and write must originate here, in server code.
//
// Env vars are read inside the factory (called per-request from handlers) so
// they resolve correctly on Cloudflare Workers, where env is injected at
// request time rather than module evaluation.
export async function getSupabaseAdmin(): Promise<SupabaseClient> {
  const url = process.env["SUPABASE_URL"];
  const serviceRoleKey = process.env["SUPABASE_SERVICE_ROLE_KEY"];
  if (!url || !serviceRoleKey) {
    throw new Error("SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY must be set");
  }
  return createClient(url, serviceRoleKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}

export const COMPANIES_ROW_ID = "companies";
