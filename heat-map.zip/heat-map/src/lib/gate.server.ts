import { redirect } from "@tanstack/react-router";
import { useSession } from "@tanstack/react-start/server";

export type GateSession = { unlocked?: boolean; name?: string };

/** useSession rejects any cookie key shorter than this. */
const MIN_SECRET_LENGTH = 32;

/**
 * Resolve the session cookie key from SESSION_SECRET.
 *
 * A missing secret throws rather than falling back to a constant baked into
 * this repo — a published fallback key would let anyone forge an unlocked
 * session, so the gate must fail closed.
 *
 * If SESSION_SECRET is set but shorter than the 32-character minimum that
 * useSession enforces, stretch it into a 64-char hex key with SHA-256 instead
 * of throwing on every request. The derived key is deterministic, so sessions
 * survive restarts, and it stays tied to the configured secret. Stretching does
 * NOT add entropy: set SESSION_SECRET to 32+ random characters and it is used
 * directly, making this path inert.
 */
async function resolveSessionPassword(): Promise<string> {
  const secret = process.env["SESSION_SECRET"];
  if (!secret) throw new Error("SESSION_SECRET is not set");
  if (secret.length >= MIN_SECRET_LENGTH) return secret;

  console.warn(
    `SESSION_SECRET is ${secret.length} characters; ${MIN_SECRET_LENGTH}+ required. ` +
      "Deriving a key via SHA-256 — set a longer SESSION_SECRET.",
  );
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(secret));
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

export async function sessionConfig() {
  return {
    password: await resolveSessionPassword(),
    name: "aedigimap-gate",
    maxAge: 60 * 60 * 24 * 7,
    cookie: {
      httpOnly: true,
      secure: true,
      // "none" so the session cookie survives inside the embedded preview iframe
      // (a lax cookie is dropped on cross-site iframe requests).
      sameSite: "none" as const,
      path: "/",
    },
  };
}

/** Constant-time compare of two byte arrays of equal length. */
function timingSafeEqualBytes(a: Uint8Array, b: Uint8Array): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) {
    const av = a[i] ?? 0;
    const bv = b[i] ?? 0;
    diff |= av ^ bv;
  }
  return diff === 0;
}

/**
 * Constant-time compare of two secrets via SHA-256 digests.
 * Uses the Web Crypto API so it is Worker-safe (no node:crypto).
 */
export async function passwordMatches(input: string, expected: string): Promise<boolean> {
  const encoder = new TextEncoder();
  const [aBuf, bBuf] = await Promise.all([
    crypto.subtle.digest("SHA-256", encoder.encode(input)),
    crypto.subtle.digest("SHA-256", encoder.encode(expected)),
  ]);
  return timingSafeEqualBytes(new Uint8Array(aBuf), new Uint8Array(bBuf));
}

export async function getGateSession() {
  return useSession<GateSession>(await sessionConfig());
}

/** Throws a redirect to /unlock when the visitor has not entered the password. */
export async function requireUnlocked() {
  const session = await getGateSession();
  if (!session.data.unlocked) throw redirect({ to: "/unlock" });
  return session;
}
