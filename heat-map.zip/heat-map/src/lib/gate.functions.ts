import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import { getGateSession, passwordMatches, requireUnlocked } from "./gate.server";
import { fetchComments, insertComment } from "./review.server";

const unlockSchema = z.object({
  password: z.string().min(1).max(200),
  name: z.string().trim().min(1, "Enter your name").max(60),
});

const commentSchema = z.object({
  body: z.string().trim().min(1, "Write a comment").max(2000),
});

export const unlockSite = createServerFn({ method: "POST" })
  .validator((data: unknown) => unlockSchema.parse(data))
  .handler(async ({ data }) => {
    const expected = process.env["SITE_PASSWORD"];
    if (!expected) throw new Error("SITE_PASSWORD is not set");
    if (!(await passwordMatches(data.password, expected))) return { ok: false as const };

    const session = await getGateSession();
    await session.update({ unlocked: true, name: data.name });
    return { ok: true as const };
  });

export const lockSite = createServerFn({ method: "POST" }).handler(async () => {
  const session = await getGateSession();
  await session.clear();
  return { ok: true as const };
});

export const getReview = createServerFn({ method: "GET" }).handler(async () => {
  const session = await requireUnlocked();
  return {
    viewer: session.data.name ?? "Teammate",
    comments: await fetchComments(),
  };
});

export const postComment = createServerFn({ method: "POST" })
  .validator((data: unknown) => commentSchema.parse(data))
  .handler(async ({ data }) => {
    const session = await requireUnlocked();
    await insertComment(session.data.name ?? "Teammate", data.body);
    return { comments: await fetchComments() };
  });
