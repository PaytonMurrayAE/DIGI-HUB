import territoryMap from "../content/territory-map.html?raw";
import clientIntake from "../content/client-intake.html?raw";

export const UPLOADED_PAGES = {
  "territory-map": { title: "Territory Map", html: territoryMap },
  "client-intake": { title: "Client Intake", html: clientIntake },
} as const;

export type UploadedPageKey = keyof typeof UPLOADED_PAGES;

export function isUploadedPageKey(value: string): value is UploadedPageKey {
  return Object.prototype.hasOwnProperty.call(UPLOADED_PAGES, value);
}
