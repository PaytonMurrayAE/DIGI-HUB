// Server-only seed of the AE Digi Map company list.
//
// The heat map (src/content/territory-map.html) ships with a hardcoded
// `raw` table of companies and derives its `baseData` from it. This module
// reproduces that exact derivation server-side so the shared store
// (/api/companies) can be seeded with the identical starting list once —
// making the Spreadsheet view and the heat map show the same set without
// relying on a client browser to self-seed (which fails when the embed
// iframe lacks the unlocked session cookie).
//
// Pure: no env, no Supabase, no browser globals. Imported only by the
// /api/companies server route. The literals below were extracted verbatim
// from src/content/territory-map.html.

import { deriveState, type Company, type CompanyLocation } from "@/lib/companies.types";

const RAW: [string, string, number, number, string][] = [
  [
    "360 Wealth Management",
    "10037 E Dynamite Blvd, Suite C-110, Scottsdale, AZ 85262",
    33.7427,
    -111.8656,
    "West",
  ],
  [
    "Advantage Retirement Group",
    "8870 Daniels Pkwy, Fort Myers, FL 33912",
    26.64063,
    -81.87231,
    "East",
  ],
  ["Armar Insurance", "Sacramento, CA", 38.58, -121.49, "West"],
  [
    "B.O.S.S. Retirement Solutions",
    "2825 E Cottonwood Pkwy, Suite 380, Salt Lake City, UT 84121",
    40.75962,
    -111.8868,
    "West",
  ],
  ["B.O.S.S. Retirement Solutions", "Boise, ID", 43.62, -116.2, "West"],
  ["B.O.S.S. Retirement Solutions", "Seattle, WA", 47.61, -122.33, "West"],
  [
    "Blue Ridge Wealth Planners",
    "9725 Cogdill Road, Suite 101, Knoxville, TN 37932",
    35.92269,
    -84.1314,
    "East",
  ],
  [
    "Centennial Advisors, LLC",
    "10815 Ranch Rd. 2222, Bldg 3C, Suite 200, Austin, TX 78730",
    30.39468,
    -97.84755,
    "Central",
  ],
  [
    "Complete Financial Solutions, Inc.",
    "8601 Six Forks Rd, Suite 400, Raleigh, NC 27615",
    35.89677,
    -78.65188,
    "East",
  ],
  [
    "Conservative Financial Solutions",
    "10403 Harrison Ave, Suite 100, Harrison, OH 45030",
    39.24851,
    -84.78743,
    "Central",
  ],
  ["Conservative Financial Solutions", "Kentucky", 37.84, -84.27, "Central"],
  ["Conservative Financial Solutions", "Indiana", 39.77, -86.16, "Central"],
  ["Cornerstone Retirement Group", "Topeka, KS", 39.05, -95.67, "Central"],
  [
    "Creekmur Wealth Advisors",
    "805 W Jackson St, Suite 301, Morton, IL 61550",
    40.6184,
    -89.46929,
    "Central",
  ],
  ["Creekmur Wealth Advisors", "Denver, CO", 39.74, -104.99, "West"],
  [
    "Crystal Lake Tax & Financial",
    "451 Coventry Ln, Suite 102, Crystal Lake, IL 60014",
    42.22827,
    -88.3305,
    "Central",
  ],
  [
    "Darwish Financial",
    "2367 Vanderbilt Beach Rd, Suite 809, Naples, FL 34109",
    26.1422,
    -81.79429,
    "East",
  ],
  [
    "Durham Loyal",
    "2250 NW 136th Ave, Suite 105, Pembroke Pines, FL 33028",
    26.02753,
    -80.32965,
    "East",
  ],
  [
    "E.A. Buck Financial Services",
    "55 Merchant St, Suite 2100, Honolulu, HI 96813",
    21.30921,
    -157.8632,
    "West",
  ],
  ["E.A. Buck Financial Services", "Colorado", 39, -105.5, "West"],
  ["E.A. Buck Financial Services", "Washington", 47.4, -120.7, "West"],
  ["E.A. Buck Financial Services", "North Carolina", 35.5, -79, "East"],
  [
    "Freedom Financial Group",
    "2057 Valleydale Rd, Suite 200, Birmingham, AL 35244",
    33.52068,
    -86.80243,
    "East",
  ],
  ["FSR Wealth Strategies", "444 N York St, Elmhurst, IL 60126", 41.9112, -87.93991, "Central"],
  [
    "Golden Reserve, LLC",
    "535 Metro Place South, Suite 100, Dublin, OH 43017",
    40.09332,
    -83.12888,
    "Central",
  ],
  [
    "Gregory Ricks Total Wealth",
    "8930 Lorraine Rd, Ste C, Gulfport, MS 39503",
    30.41057,
    -89.02798,
    "East",
  ],
  [
    "Gregory Ricks Total Wealth",
    "2800 Veterans Memorial Blvd, Suite 170, Metairie, LA 70002",
    30.00229,
    -90.15015,
    "Central",
  ],
  ["Ilgenfritz Financial Group", "1603 Rodney Road, York, PA 17408", 39.97742, -76.76548, "East"],
  [
    "Integrated Wealth Management",
    "1790 Town Park Blvd, Suite K, Uniontown, OH 44685",
    40.95004,
    -81.46834,
    "Central",
  ],
  [
    "J. Biance Financial",
    "735 5th Avenue West, Hendersonville, NC 28739",
    35.31665,
    -82.46907,
    "East",
  ],
  ["Jennings Insurance Group", "Osage Beach, MO", 38.15, -92.62, "Central"],
  ["Kirsner Wealth Management", "Boca Raton, FL", 26.37, -80.13, "East"],
  ["Layman Lewis Financial Group", "Denver, CO", 39.74, -104.99, "West"],
  [
    "Life Design Financial",
    "500 N. State College Blvd., Suite 1100, Orange, CA 92868",
    33.87435,
    -117.88953,
    "West",
  ],
  ["Main Street Advisors", "13920 N Western Ave, Edmond, OK 73013", 35.67611, -97.53183, "Central"],
  ["McIntosh & Associates", "8282 Midland Rd, Freeland, MI 48623", 43.52922, -84.12678, "Central"],
  [
    "Mediate Financial Services",
    "8166 Market St Ste N, Boardman, OH 44512",
    41.00117,
    -80.66285,
    "Central",
  ],
  ["Merkle Retirement Planning", "Des Moines, IA", 41.59, -93.62, "Central"],
  [
    "Miller Retirement Group",
    "805 New Hampshire Street, Suite B, Lawrence, KS 66044",
    38.96908,
    -95.23506,
    "Central",
  ],
  ["Mitch Lyons Wealth, LLC", "Orange County, CA", 33.72, -117.83, "West"],
  ["Mosley Wealth Management", "Livingston Parish, LA", 30.48, -90.92, "Central"],
  ["Presley Wealth Management", "Lawrenceville, GA", 33.96, -83.99, "East"],
  ["Retire Wise, LLC", "Overland Park, KS", 38.98, -94.67, "Central"],
  ["Retirement Solutions Group", "Jackson, MI", 42.25, -84.4, "Central"],
  ["Richmond Brothers", "Denver, CO", 39.74, -104.99, "West"],
  ["Rooted Tax Advisors", "Dayton, OH", 39.76, -84.19, "Central"],
  ["Rooted Wealth Advisors", "Southern California", 34.05, -118.25, "West"],
  ["Russell Total Wealth and Wellness", "Corona, CA", 33.88, -117.57, "West"],
  ["Safeguard Investment Advisory Group", "Chicago, IL", 41.88, -87.63, "Central"],
  ["Safeguard Investment Advisory Group, LLC", "Illinois", 40, -89.2, "Central"],
  ["Safeguard Investment Advisory Group, LLC", "Florida", 27.8, -81.7, "East"],
  ["Saturn Wealth", "Phoenix, AZ", 33.45, -112.07, "West"],
  ["Scott Tucker Solutions, Inc.", "Winter Garden, FL", 28.56, -81.59, "East"],
  ["Slagle Financial", "Elmhurst, IL", 41.9, -87.94, "Central"],
  ["Strategy Financial Group", "Kansas City, MO", 39.1, -94.58, "Central"],
  ["The Lifewealth Group", "Hendersonville, TN", 36.3, -86.62, "East"],
  ["Wellment Financial", "Virtual / National", 39, -98, "National / Virtual"],
  ["Ridgegate Financial", "Virtual / National", 39, -98, "National / Virtual"],
  ["Wingate", "Virtual / National", 39, -98, "National / Virtual"],
  ["SME (Data SME & Sync SME)", "Virtual / National", 39, -98, "National / Virtual"],
  ["LWG (Coaching)", "Virtual / National", 39, -98, "National / Virtual"],
  [
    "Wood Financial Group",
    "181 East Main Street, Suite 7, Hendersonville, TN 37075",
    36.30688,
    -86.60761,
    "East",
  ],
];

const SIGNATURE_BY_NAME: Record<string, string> = {
  "B.O.S.S. Retirement Solutions": "Legend",
  "Blue Ridge Wealth Planners": "Elite",
  "Centennial Advisors, LLC": "Premier",
  "Conservative Financial Solutions": "Legend",
  "Creekmur Wealth Advisors": "Legend",
  "Crystal Lake Tax & Financial": "Premier",
  "Darwish Financial": "New Advisor",
  "E.A. Buck Financial Services": "Legend",
  "Freedom Financial Group": "Legend",
  "Golden Reserve, LLC": "Under 3M",
  "Gregory Ricks Total Wealth": "Legend",
  "Ilgenfritz Financial Group": "Legend",
  "Integrated Wealth Management": "Elite",
  "J. Biance Financial": "Elite",
  "Kirsner Wealth Management": "Elite",
  "Layman Lewis Financial Group": "Elite",
  "Life Design Financial": "Premier",
  "Main Street Advisors": "3M-9.9M",
  "McIntosh & Associates": "Elite",
  "Mediate Financial Services": "Premier",
  "Merkle Retirement Planning": "Legend",
  "Miller Retirement Group": "Premier",
  "Mosley Wealth Management": "Elite",
  "Retirement Solutions Group": "Legend",
  "Ridgegate Financial": "Premier",
  "Russell Total Wealth and Wellness": "Legend",
  "Safeguard Investment Advisory Group, LLC": "Legend",
  "Saturn Wealth": "Elite",
  "Scott Tucker Solutions, Inc.": "Premier",
  "Slagle Financial": "Legend",
  "Wellment Financial": "Elite",
  "Wood Financial Group": "Legend",
  Wingate: "New Advisor",
};

const VERIFIED_RAW_INDICES = new Set<number>([
  0, 1, 3, 6, 7, 8, 9, 13, 15, 16, 17, 18, 22, 23, 24, 25, 26, 27, 28, 29, 33, 34, 35, 36, 38, 61,
]);

let cache: Company[] | null = null;

/** The heat map's hardcoded starting company list, derived server-side. */
export function getBaseCompanies(): Company[] {
  if (cache) return cache;

  const baseMap: Record<string, Company> = {};
  RAW.forEach((d, i) => {
    const name = d[0];
    if (!baseMap[name]) {
      baseMap[name] = {
        id: "base-" + Object.keys(baseMap).length,
        name,
        team: "Unassigned",
        signatureStatus: SIGNATURE_BY_NAME[name] || "",
        locations: [] as CompanyLocation[],
      };
    }
    baseMap[name].locations.push({
      id: "loc-" + i,
      label: d[1],
      lat: d[2],
      lng: d[3],
      markets: true,
      coverage: "none",
      marketDensity: "Moderate",
      state: deriveState(d[1]),
      addressVerified: VERIFIED_RAW_INDICES.has(i),
      campaignTypes: ["General"],
    });
  });

  const baseData = Object.values(baseMap);
  baseData.push({
    id: "base-noloc-1",
    name: "Impact Wealth Management",
    team: "Unassigned",
    signatureStatus: "Premier",
    locations: [
      {
        id: "loc-noloc-1",
        label: "No location on file yet",
        lat: null,
        lng: null,
        markets: false,
        coverage: "none",
        marketDensity: "Moderate",
        state: "",
        addressVerified: false,
        campaignTypes: ["General"],
      },
    ],
  });

  cache = baseData;
  return cache;
}
