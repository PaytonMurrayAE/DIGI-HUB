// Shared type for a company in the territory map.
//
// Mirrors the shape the embedded heat map (src/content/territory-map.html)
// reads and writes via /api/companies. Kept client-safe so both the map and
// the spreadsheet view agree on the contract.

export type CampaignType = "HVO" | "Event" | "General" | "HNW" | "Branding" | "Other";

export type SignatureStatus =
  "Legend" | "Elite" | "Premier" | "3M-9.9M" | "Under 3M" | "New Advisor" | "";

export type Team = "Eagle" | "Ideate" | "Unassigned" | "";

export type Coverage = "none" | "30" | "50" | "75" | "100" | "150" | "200" | "250" | "statewide";

export type MarketDensity = "Low" | "Moderate" | "High" | "Very High";

export type CompanyLocation = {
  id: string;
  label: string;
  lat: number | null;
  lng: number | null;
  markets: boolean;
  /** Coaching office flag — shown alongside Active/Inactive in the sheet. */
  coaching?: boolean;
  coverage: Coverage | string;
  marketDensity: MarketDensity | string;
  state: string;
  addressVerified: boolean;
  campaignTypes: CampaignType[] | string[];
};

export type Company = {
  id: string;
  name: string;
  team: Team | string;
  signatureStatus: SignatureStatus | string;
  locations: CompanyLocation[];
};

export const SIGNATURE_STATUSES: SignatureStatus[] = [
  "Legend",
  "Elite",
  "Premier",
  "3M-9.9M",
  "Under 3M",
  "New Advisor",
];

export const TEAMS: Team[] = ["Eagle", "Ideate", "Unassigned"];

export const CAMPAIGN_TYPES: CampaignType[] = [
  "HVO",
  "Event",
  "General",
  "HNW",
  "Branding",
  "Other",
];

export const COVERAGE_OPTIONS: { value: Coverage; label: string }[] = [
  { value: "none", label: "No range set" },
  { value: "30", label: "30 miles" },
  { value: "50", label: "50 miles" },
  { value: "75", label: "75 miles" },
  { value: "100", label: "100 miles" },
  { value: "150", label: "150 miles" },
  { value: "200", label: "200 miles" },
  { value: "250", label: "250 miles" },
  { value: "statewide", label: "Statewide" },
];

export const DENSITY_OPTIONS: MarketDensity[] = ["Low", "Moderate", "High", "Very High"];

export const US_STATES = [
  "Alabama",
  "Alaska",
  "Arizona",
  "Arkansas",
  "California",
  "Colorado",
  "Connecticut",
  "Delaware",
  "District of Columbia",
  "Florida",
  "Georgia",
  "Hawaii",
  "Idaho",
  "Illinois",
  "Indiana",
  "Iowa",
  "Kansas",
  "Kentucky",
  "Louisiana",
  "Maine",
  "Maryland",
  "Massachusetts",
  "Michigan",
  "Minnesota",
  "Mississippi",
  "Missouri",
  "Montana",
  "Nebraska",
  "Nevada",
  "New Hampshire",
  "New Jersey",
  "New Mexico",
  "New York",
  "North Carolina",
  "North Dakota",
  "Ohio",
  "Oklahoma",
  "Oregon",
  "Pennsylvania",
  "Rhode Island",
  "South Carolina",
  "South Dakota",
  "Tennessee",
  "Texas",
  "Utah",
  "Vermont",
  "Virginia",
  "Washington",
  "West Virginia",
  "Wisconsin",
  "Wyoming",
];

/** Derive a US state name from a free-text label, mirroring the heat map. */
export function deriveState(label: string): string {
  if (!label) return "";
  const l = String(label).trim();
  const m = l.match(/,\s*([A-Za-z]{2})(?:\s+\d{5}(?:-\d{4})?)?$/);
  if (m && m[1]) {
    const abbr = m[1].toUpperCase();
    const ABBR: Record<string, string> = {
      AL: "Alabama",
      AK: "Alaska",
      AZ: "Arizona",
      AR: "Arkansas",
      CA: "California",
      CO: "Colorado",
      CT: "Connecticut",
      DE: "Delaware",
      DC: "District of Columbia",
      FL: "Florida",
      GA: "Georgia",
      HI: "Hawaii",
      ID: "Idaho",
      IL: "Illinois",
      IN: "Indiana",
      IA: "Iowa",
      KS: "Kansas",
      KY: "Kentucky",
      LA: "Louisiana",
      ME: "Maine",
      MD: "Maryland",
      MA: "Massachusetts",
      MI: "Michigan",
      MN: "Minnesota",
      MS: "Mississippi",
      MO: "Missouri",
      MT: "Montana",
      NE: "Nebraska",
      NV: "Nevada",
      NH: "New Hampshire",
      NJ: "New Jersey",
      NM: "New Mexico",
      NY: "New York",
      NC: "North Carolina",
      ND: "North Dakota",
      OH: "Ohio",
      OK: "Oklahoma",
      OR: "Oregon",
      PA: "Pennsylvania",
      RI: "Rhode Island",
      SC: "South Carolina",
      SD: "South Dakota",
      TN: "Tennessee",
      TX: "Texas",
      UT: "Utah",
      VT: "Vermont",
      VA: "Virginia",
      WA: "Washington",
      WV: "West Virginia",
      WI: "Wisconsin",
      WY: "Wyoming",
    };
    if (ABBR[abbr]) return ABBR[abbr];
  }
  const direct = US_STATES.find((s) => s.toLowerCase() === l.toLowerCase());
  if (direct) return direct;
  const lower = l.toLowerCase();
  const special: Record<string, string> = {
    "southern california": "California",
    "northern california": "California",
    "orange county": "California",
    "virtual / national": "",
    "national / virtual": "",
  };
  return special[lower] ?? "";
}

export function blankCompany(): Company {
  return {
    id: `custom-${Date.now()}`,
    name: "",
    team: "",
    signatureStatus: "",
    locations: [blankLocation()],
  };
}

export function blankLocation(): CompanyLocation {
  return {
    id: `loc-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    label: "",
    lat: null,
    lng: null,
    markets: true,
    coverage: "none",
    marketDensity: "Moderate",
    state: "",
    addressVerified: true,
    campaignTypes: ["General"],
  };
}
