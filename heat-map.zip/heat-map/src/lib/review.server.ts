export type ReviewComment = {
  id: string;
  author_name: string;
  body: string;
  created_at: string;
};

/**
 * Comment store backed by a JSON file on disk (Node runtime).
 * Falls back to an in-memory array when the filesystem is unavailable
 * (e.g. an edge/Worker runtime), so the app never crashes.
 *
 * NOTE: This replaces the original Supabase `review_comments` table.
 * Comments persist across requests on the Node preview server; on an
 * edge deploy they live only in memory for the process lifetime.
 */

const DATA_DIR = "data";
const DATA_FILE = `${DATA_DIR}/comments.json`;
const memoryStore: ReviewComment[] = [];

async function readStore(): Promise<ReviewComment[]> {
  try {
    const fs = await import("node:fs/promises");
    const raw = await fs.readFile(DATA_FILE, "utf8");
    const parsed = JSON.parse(raw) as ReviewComment[];
    memoryStore.length = 0;
    memoryStore.push(...parsed);
    return parsed;
  } catch {
    return [...memoryStore];
  }
}

async function writeStore(comments: ReviewComment[]): Promise<void> {
  memoryStore.length = 0;
  memoryStore.push(...comments);
  try {
    const fs = await import("node:fs/promises");
    await fs.mkdir(DATA_DIR, { recursive: true });
    await fs.writeFile(DATA_FILE, JSON.stringify(comments, null, 2), "utf8");
  } catch {
    // No filesystem available — memory store still holds the data for this process.
  }
}

export async function fetchComments(): Promise<ReviewComment[]> {
  const comments = await readStore();
  return [...comments].sort((a, b) => b.created_at.localeCompare(a.created_at)).slice(0, 200);
}

export async function insertComment(authorName: string, body: string): Promise<ReviewComment> {
  const comments = await readStore();
  const comment: ReviewComment = {
    id: crypto.randomUUID(),
    author_name: authorName,
    body,
    created_at: new Date().toISOString(),
  };
  comments.push(comment);
  await writeStore(comments);
  return comment;
}
