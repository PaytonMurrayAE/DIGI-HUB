// Modal for setting an office location from a Google Maps link or coordinates.
//
// Extracts exact coordinates from:
//   - Full Google Maps URLs (/@lat,lng or !3dlat!4dlng)
//   - Share / search links (?q=lat,lng or ll=lat,lng)
//   - Raw latitude, longitude pairs (e.g. "30.38612, -90.09341")
//   - Google Maps place URLs with embedded address queries (geocoded via free Nominatim)
//
// Short links (maps.app.goo.gl) cannot be resolved client-side due to CORS,
// so if the user pastes one, we provide clear helper guidance or expand via backend route.

import { Check, Link2, Loader2, MapPin, X } from "lucide-react";
import { useState } from "react";

import { Button } from "@/components/ui/button";

export type PickedLocation = { lat: number; lng: number; label: string };

async function reverseGeocode(lat: number, lng: number): Promise<string> {
  try {
    const r = await fetch(
      `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=18&addressdetails=0`,
    );
    if (!r.ok) return `${lat.toFixed(5)}, ${lng.toFixed(5)}`;
    const j = await r.json();
    return j.display_name || `${lat.toFixed(5)}, ${lng.toFixed(5)}`;
  } catch {
    return `${lat.toFixed(5)}, ${lng.toFixed(5)}`;
  }
}

async function forwardGeocode(query: string): Promise<{ lat: number; lng: number } | null> {
  try {
    const r = await fetch(
      `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=1`,
    );
    if (!r.ok) return null;
    const j = await r.json();
    if (Array.isArray(j) && j.length > 0) {
      const lat = parseFloat(j[0].lat);
      const lng = parseFloat(j[0].lon);
      if (Number.isFinite(lat) && Number.isFinite(lng)) return { lat, lng };
    }
    return null;
  } catch {
    return null;
  }
}

/**
 * Robust Google Maps link & coordinate parser:
 * 1. Raw numbers: "30.386121, -90.093412"
 * 2. @lat,lng in path (e.g. /@30.386121,-90.093412,17z)
 * 3. !3dlat!4dlng in protobuf data params (standard in desktop Google Maps place URLs)
 * 4. Query params (?q=lat,lng, ?query=lat,lng, ?ll=lat,lng, ?destination=lat,lng)
 * 5. Path coordinates (/dir//lat,lng or /maps/lat,lng)
 * 6. Place name in path (/maps/place/Some+Address) -> forward geocode
 */
export async function parseGoogleLocation(
  input: string,
): Promise<{ lat: number; lng: number } | null> {
  const trimmed = input.trim();
  if (!trimmed) return null;

  // 1. Direct coordinates pasted (e.g. "30.386121, -90.093412")
  const rawCoords = trimmed.match(/^(-?\d{1,2}(?:\.\d+)?)\s*,\s*(-?\d{1,3}(?:\.\d+)?)$/);
  if (rawCoords && rawCoords[1] && rawCoords[2]) {
    const lat = parseFloat(rawCoords[1]);
    const lng = parseFloat(rawCoords[2]);
    if (
      Number.isFinite(lat) &&
      Number.isFinite(lng) &&
      Math.abs(lat) <= 90 &&
      Math.abs(lng) <= 180
    ) {
      return { lat, lng };
    }
  }

  // 2. @lat,lng in URL path
  const atMatch = trimmed.match(/@(-?\d+\.?\d*),(-?\d+\.?\d*)/);
  if (atMatch && atMatch[1] && atMatch[2]) {
    const lat = parseFloat(atMatch[1]);
    const lng = parseFloat(atMatch[2]);
    if (
      Number.isFinite(lat) &&
      Number.isFinite(lng) &&
      Math.abs(lat) <= 90 &&
      Math.abs(lng) <= 180
    ) {
      return { lat, lng };
    }
  }

  // 3. !3dlat!4dlng in Google Maps data parameters
  const dataMatch = trimmed.match(/!3d(-?\d+\.?\d*)!4d(-?\d+\.?\d*)/);
  if (dataMatch && dataMatch[1] && dataMatch[2]) {
    const lat = parseFloat(dataMatch[1]);
    const lng = parseFloat(dataMatch[2]);
    if (
      Number.isFinite(lat) &&
      Number.isFinite(lng) &&
      Math.abs(lat) <= 90 &&
      Math.abs(lng) <= 180
    ) {
      return { lat, lng };
    }
  }

  // 4. Query params with coordinates (?q=lat,lng, ?ll=lat,lng, ?query=lat,lng)
  const queryCoordMatch = trimmed.match(
    /[?&](?:q|query|ll|sll|destination)=(-?\d+\.?\d*)[,+](-?\d+\.?\d*)/i,
  );
  if (queryCoordMatch && queryCoordMatch[1] && queryCoordMatch[2]) {
    const lat = parseFloat(queryCoordMatch[1]);
    const lng = parseFloat(queryCoordMatch[2]);
    if (
      Number.isFinite(lat) &&
      Number.isFinite(lng) &&
      Math.abs(lat) <= 90 &&
      Math.abs(lng) <= 180
    ) {
      return { lat, lng };
    }
  }

  // 5. Path coordinates e.g. /dir//30.386121,-90.093412
  const pathCoordMatch = trimmed.match(/\/(-?\d{1,2}\.\d+)[,/](-?\d{1,3}\.\d+)/);
  if (pathCoordMatch && pathCoordMatch[1] && pathCoordMatch[2]) {
    const lat = parseFloat(pathCoordMatch[1]);
    const lng = parseFloat(pathCoordMatch[2]);
    if (Math.abs(lat) <= 90 && Math.abs(lng) <= 180) {
      return { lat, lng };
    }
  }

  // 6. Check if query param or path is an address name (e.g. /place/4030+Lonesome+Rd or ?q=4030+Lonesome+Rd)
  try {
    const u = new URL(trimmed);
    const q = u.searchParams.get("q") || u.searchParams.get("query");
    if (q) {
      const geo = await forwardGeocode(q);
      if (geo) return geo;
    }
    const placeMatch = u.pathname.match(/\/place\/([^/@]+)/);
    if (placeMatch && placeMatch[1]) {
      const placeQuery = decodeURIComponent(placeMatch[1].replace(/\+/g, " "));
      const geo = await forwardGeocode(placeQuery);
      if (geo) return geo;
    }
  } catch {
    // Not a valid URL object; try checking if the whole string is an address
    const geo = await forwardGeocode(trimmed);
    if (geo) return geo;
  }

  return null;
}

export function GoogleLinkModal({
  currentLabel,
  currentLat,
  currentLng,
  onPick,
  onClose,
}: {
  currentLabel: string;
  currentLat: number | null;
  currentLng: number | null;
  onPick: (p: PickedLocation) => void;
  onClose: () => void;
}) {
  const [link, setLink] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [resolved, setResolved] = useState<{ lat: number; lng: number; label: string } | null>(
    currentLat && currentLng ? { lat: currentLat, lng: currentLng, label: currentLabel } : null,
  );

  async function handleApply() {
    const trimmed = link.trim();
    if (!trimmed) return;

    setBusy(true);
    setError(null);

    // If it is a short link like maps.app.goo.gl or goo.gl/maps, warn user to open it first
    if (/maps\.app\.goo\.gl|goo\.gl\/maps/i.test(trimmed)) {
      setError(
        "Short Google Maps links (maps.app.goo.gl) hide coordinates behind a redirect. Please open the link in your browser first, then copy the full URL from the address bar (it will contain @lat,lng) and paste it here.",
      );
      setBusy(false);
      return;
    }

    try {
      const coords = await parseGoogleLocation(trimmed);
      if (!coords) {
        setError(
          "Couldn't extract coordinates from that input. Please paste a full Google Maps URL with @lat,lng, or paste raw coordinates directly (e.g. '30.38612, -90.09341').",
        );
        setBusy(false);
        return;
      }

      // Reverse geocode the extracted coordinates to get a clean address label
      const label = await reverseGeocode(coords.lat, coords.lng);
      setResolved({ lat: coords.lat, lng: coords.lng, label });
    } catch {
      setError(
        "An error occurred while parsing the location. Please check the link and try again.",
      );
    } finally {
      setBusy(false);
    }
  }

  function handleConfirm() {
    if (!resolved) return;
    onPick(resolved);
  }

  return (
    <div className="fixed inset-0 z-[10000] flex items-center justify-center bg-black/70 p-4">
      <div className="panel w-full max-w-xl overflow-hidden shadow-2xl">
        <div className="flex items-center justify-between border-b border-border px-5 py-4">
          <div className="flex items-center gap-2">
            <Link2 className="h-5 w-5 text-[#9ec5fe]" aria-hidden="true" />
            <h2 className="text-lg font-semibold">Set location from Google Maps</h2>
          </div>
          <Button variant="ghost" size="sm" onClick={onClose} aria-label="Close">
            <X className="h-4 w-4" />
          </Button>
        </div>

        <div className="space-y-4 p-5">
          <p className="text-xs text-muted-foreground leading-relaxed">
            Paste a full Google Maps URL from your address bar (or type raw coordinates like{" "}
            <code className="rounded bg-muted px-1 py-0.5 text-[#9ec5fe]">30.38612, -90.09341</code>
            ). We extract the coordinates directly without relying on any paid API.
          </p>

          <div className="space-y-2">
            <label htmlFor="gmaps-input" className="block text-xs font-semibold text-[#9ec5fe]">
              Google Maps link or coordinates
            </label>
            <div className="flex gap-2">
              <input
                id="gmaps-input"
                type="text"
                value={link}
                onChange={(e) => setLink(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    handleApply();
                  }
                }}
                placeholder="https://www.google.com/maps/place/.../@30.386121,-90.093412,17z"
                className="flex-1 rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground outline-none focus-visible:ring-2 focus-visible:ring-ring"
              />
              <Button
                size="sm"
                variant="secondary"
                onClick={handleApply}
                disabled={busy || !link.trim()}
              >
                {busy ? (
                  <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" aria-hidden="true" />
                ) : (
                  <Check className="mr-1.5 h-3.5 w-3.5" aria-hidden="true" />
                )}
                Parse link
              </Button>
            </div>
          </div>

          {error ? (
            <div className="rounded-md border border-destructive/50 bg-destructive/10 p-3 text-xs text-destructive leading-relaxed">
              {error}
            </div>
          ) : null}

          {resolved ? (
            <div className="rounded-lg border border-[#2266FF]/40 bg-[#2266FF]/10 p-4 text-sm">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-[#9ec5fe]">
                <MapPin className="h-3.5 w-3.5 text-[#9ec5fe]" aria-hidden="true" />
                Location resolved
              </div>
              <p className="mt-1.5 font-medium text-foreground text-sm">{resolved.label}</p>
              <div className="mt-2 flex items-center gap-2 text-xs text-muted-foreground font-mono">
                <span>Lat: {resolved.lat.toFixed(5)}</span>
                <span>•</span>
                <span>Lng: {resolved.lng.toFixed(5)}</span>
              </div>
            </div>
          ) : null}

          <div className="rounded-md bg-muted/40 p-3 text-xs text-muted-foreground space-y-1">
            <p className="font-semibold text-foreground">How to grab the exact Google Maps link:</p>
            <ol className="list-decimal list-inside space-y-0.5">
              <li>Search for the location on Google Maps in your browser.</li>
              <li>
                Right-click the red pin and click the coordinates (this copies them), or copy the
                URL from the address bar.
              </li>
              <li>
                Paste either here and click <b>Parse link</b>.
              </li>
            </ol>
          </div>
        </div>

        <div className="flex justify-end gap-2 border-t border-border px-5 py-4">
          <Button variant="secondary" size="sm" onClick={onClose}>
            Cancel
          </Button>
          <Button
            size="sm"
            onClick={handleConfirm}
            disabled={!resolved || busy}
            className="bg-[#2266FF] hover:bg-[#2266FF]/90 text-white"
          >
            <Check className="mr-1.5 h-4 w-4" aria-hidden="true" />
            Apply to office
          </Button>
        </div>
      </div>
    </div>
  );
}
