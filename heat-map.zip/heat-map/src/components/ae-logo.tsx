import { cn } from "@/lib/utils";

type AeLogoProps = {
  variant?: "light" | "dark";
  className?: string;
};

/**
 * AE Digital wordmark — a stand-in for the original hosted logo PNGs.
 * `variant="light"` renders white text for dark backgrounds (the review header);
 * `variant="dark"` renders the dark wordmark for light backgrounds (the unlock card).
 */
export function AeLogo({ variant = "dark", className }: AeLogoProps) {
  const markColor = variant === "light" ? "#ffffff" : "#2266FF";
  const wordColor = variant === "light" ? "#ffffff" : "#212020";
  const subColor = variant === "light" ? "rgba(255,255,255,0.65)" : "#F75A03";

  return (
    <div className={cn("flex items-center gap-3", className)}>
      <img
        src="https://vibe.filesafe.space/1789407187340213449/attachments/1d11d94c-8123-4aea-81cc-29073d801311.png"
        alt="AE Digital emblem"
        className="h-12 w-auto object-contain shrink-0"
      />
      <div className="flex flex-col justify-center leading-none">
        <span
          className="font-display text-[22px] font-bold tracking-tight"
          style={{ color: wordColor }}
        >
          DIGITAL
        </span>
        <span
          className="font-sans text-[10px] font-semibold tracking-[0.22em] mt-1"
          style={{ color: subColor }}
        >
          MARKETING
        </span>
      </div>
    </div>
  );
}
