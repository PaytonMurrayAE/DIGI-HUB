// Editable spreadsheet view of the company list.
//
// The "Excel sheet" the user asked for lives here, in the app: every teammate
// edits the same grid, writes go to /api/companies (shared Supabase store),
// and near-real-time polling brings in other people's changes. Switching back
// to the Heat Map view reloads the iframe, which re-GETs the store, so the map
// reflects whatever was edited here.

import { ArrowLeft, Check, Link2, Loader2, Map, Plus, Search, Trash2 } from "lucide-react";
import { useEffect, useRef, useState } from "react";

import { AeLogo } from "@/components/ae-logo";
import { Button } from "@/components/ui/button";
import { GoogleLinkModal, type PickedLocation } from "@/components/google-link-modal";
import { useCompanies } from "@/hooks/use-companies";
import {
  CAMPAIGN_TYPES,
  COVERAGE_OPTIONS,
  DENSITY_OPTIONS,
  SIGNATURE_STATUSES,
  TEAMS,
  US_STATES,
  blankCompany,
  blankLocation,
  deriveState,
  type Company,
  type CompanyLocation,
} from "@/lib/companies.types";

const STATE_OPTIONS = ["", ...US_STATES];

export function SpreadsheetView({ onBackToMap }: { onBackToMap: () => void }) {
  const companies = useCompanies();
  const [draft, setDraft] = useState<Company[]>([]);
  const [dirty, setDirty] = useState(false);
  const [search, setSearch] = useState("");
  const [pinTarget, setPinTarget] = useState<{
    companyId: string;
    locId: string;
    lat: number | null;
    lng: number | null;
  } | null>(null);
  const lastVersion = useRef<number | null>(null);
  // The store version the current draft is based on. Tracked separately from
  // lastVersion so a save can PUT the correct base version even after a poll
  // advanced companies.version while we held unsaved edits (see save()).
  const draftBaseVersion = useRef<number | null>(null);
  // True when a poll brought a newer version while we had unsaved edits. We
  // keep the user's draft and show a notice instead of silently clobbering it.
  const [staleNotice, setStaleNotice] = useState(false);

  // Whenever the store version changes, adopt the canonical copy — UNLESS the
  // user has unsaved edits. In that case we keep their draft and flag that a
  // newer version exists, so adding an office isn't silently wiped by a
  // teammate's save (or the heat map's self-seed in another tab).
  useEffect(() => {
    if (companies.version === lastVersion.current) return;
    if (dirty) {
      setStaleNotice(true);
      return;
    }
    lastVersion.current = companies.version;
    draftBaseVersion.current = companies.version;
    setDraft(structuredClone(companies.data));
    setStaleNotice(false);
  }, [companies.version, companies.data, dirty]);

  function update(mutator: (list: Company[]) => void) {
    setDraft((prev) => {
      const next = structuredClone(prev);
      mutator(next);
      return next;
    });
    setDirty(true);
  }

  function addCompany() {
    update((list) => list.push(blankCompany()));
    // Scroll the freshly added card into view so the user sees it appear.
    requestAnimationFrame(() => {
      const cards = document.querySelectorAll<HTMLElement>("[data-company-card]");
      cards[cards.length - 1]?.scrollIntoView({ behavior: "smooth", block: "center" });
    });
  }

  function removeCompany(id: string) {
    update((list) => {
      const i = list.findIndex((c) => c.id === id);
      if (i >= 0) list.splice(i, 1);
    });
  }

  function setCompany(id: string, patch: Partial<Company>) {
    update((list) => {
      const c = list.find((x) => x.id === id);
      if (c) Object.assign(c, patch);
    });
  }

  function addLocation(companyId: string) {
    update((list) => {
      const c = list.find((x) => x.id === companyId);
      if (c) c.locations.push(blankLocation());
    });
  }

  function removeLocation(companyId: string, locId: string) {
    update((list) => {
      const c = list.find((x) => x.id === companyId);
      if (c && c.locations.length > 1) {
        c.locations = c.locations.filter((l) => l.id !== locId);
      }
    });
  }

  function setLocation(companyId: string, locId: string, patch: Partial<CompanyLocation>) {
    update((list) => {
      const c = list.find((x) => x.id === companyId);
      const l = c?.locations.find((x) => x.id === locId);
      if (l) Object.assign(l, patch);
    });
  }

  function onAddressBlur(companyId: string, loc: CompanyLocation) {
    if (!loc.state) {
      const state = deriveState(loc.label);
      if (state) setLocation(companyId, loc.id, { state });
    }
  }

  function applyPickedLocation(companyId: string, locId: string, picked: PickedLocation) {
    setLocation(companyId, locId, {
      lat: picked.lat,
      lng: picked.lng,
      label: picked.label,
      state: deriveState(picked.label),
      addressVerified: true,
    });
  }

  async function save() {
    // Drop empty companies / locations before writing.
    const clean = draft
      .filter((c) => c.name.trim())
      .map((c) => ({
        ...c,
        locations: c.locations
          .filter((l) => l.label.trim())
          .map((l) => ({
            ...l,
            campaignTypes: l.campaignTypes.length ? l.campaignTypes : ["General"],
          })),
      }));
    // PUT the version the draft is based on, not the latest polled version.
    // If a teammate saved in between, the server returns 409 and the hook
    // reloads their version — surfacing a real conflict instead of silently
    // overwriting their save.
    const result = await companies.save(clean, draftBaseVersion.current ?? undefined);
    if (result.ok) {
      setDirty(false);
      setStaleNotice(false);
      draftBaseVersion.current = result.version;
      lastVersion.current = result.version;
    }
  }

  // Discard local edits and load the latest shared version. Offered in the
  // stale-notice banner so the user can choose to keep their edits or pull
  // a teammate's save.
  function discardAndReload() {
    lastVersion.current = companies.version;
    draftBaseVersion.current = companies.version;
    setDraft(structuredClone(companies.data));
    setDirty(false);
    setStaleNotice(false);
  }

  const totalOffices = draft.reduce((n, c) => n + c.locations.length, 0);

  const term = search.trim().toLowerCase();
  const filtered = term
    ? draft.filter((c) => {
        const inCompany =
          c.name.toLowerCase().includes(term) ||
          c.team.toLowerCase().includes(term) ||
          c.signatureStatus.toLowerCase().includes(term);
        const inLocations = c.locations.some(
          (l) =>
            l.label.toLowerCase().includes(term) ||
            l.state.toLowerCase().includes(term) ||
            l.coverage.toLowerCase().includes(term) ||
            l.marketDensity.toLowerCase().includes(term) ||
            l.campaignTypes.some((ct) => ct.toLowerCase().includes(term)),
        );
        return inCompany || inLocations;
      })
    : draft;

  return (
    <div
      className="spreadsheet-shell dark relative min-h-screen bg-[#1a1a1c] bg-cover bg-center bg-no-repeat"
      style={{
        backgroundImage:
          "url('https://vibe.filesafe.space/1789407187340213449/attachments/87f918e5-4494-4dba-996f-8a850ed12f49.png')",
      }}
    >
      <header className="surface-deep border-b-4 border-transparent [border-image:var(--gradient-brand)_1]">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-4 px-6 py-5">
          <div className="flex items-center gap-4">
            <AeLogo variant="light" className="h-11 w-auto" />
            <div>
              <p className="font-display text-xs font-semibold uppercase tracking-[0.18em] opacity-70">
                AE Digi Map
              </p>
              <h1 className="text-xl font-semibold">Company spreadsheet</h1>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="secondary" size="sm" onClick={onBackToMap}>
              <Map className="mr-1.5 h-4 w-4" aria-hidden="true" />
              Back to heat map
            </Button>
            <Button size="sm" onClick={save} disabled={companies.saving || !dirty}>
              {companies.saving ? (
                <Loader2 className="mr-1.5 h-4 w-4 animate-spin" aria-hidden="true" />
              ) : (
                <Check className="mr-1.5 h-4 w-4" aria-hidden="true" />
              )}
              {companies.saving ? "Saving…" : "Save for everyone"}
            </Button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-6 py-8">
        <div className="panel mb-5 flex flex-wrap items-center justify-between gap-4 px-5 py-4 text-sm">
          <div className="flex items-center gap-6">
            <span>
              <b className="text-foreground">{draft.length}</b>{" "}
              <span className="text-muted-foreground">companies</span>
            </span>
            <span>
              <b className="text-foreground">{totalOffices}</b>{" "}
              <span className="text-muted-foreground">offices</span>
            </span>
            <span>
              <b className="text-foreground">{companies.version ?? "—"}</b>{" "}
              <span className="text-muted-foreground">version</span>
            </span>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative">
              <Search
                className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
                aria-hidden="true"
              />
              <input
                type="search"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search offices, companies, states…"
                aria-label="Search companies and offices"
                className="w-72 rounded-md border border-input bg-background py-2 pl-9 pr-3 text-sm text-foreground outline-none focus-visible:ring-2 focus-visible:ring-ring"
              />
            </div>
            <Button size="sm" variant="secondary" onClick={addCompany}>
              <Plus className="mr-1.5 h-4 w-4" aria-hidden="true" />
              Add company
            </Button>
          </div>
        </div>

        {companies.loading ? (
          <div className="panel flex items-center justify-center p-12 text-sm text-muted-foreground">
            <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden="true" />
            Loading the shared company list…
          </div>
        ) : (
          <>
            {companies.conflict ? (
              <div
                role="alert"
                className="panel mb-4 border-l-4 border-l-amber-500 px-5 py-3 text-sm text-amber-700"
              >
                {companies.conflict}
              </div>
            ) : null}
            {companies.error ? (
              <div
                role="alert"
                className="panel mb-4 border-l-4 border-l-destructive px-5 py-3 text-sm text-destructive"
              >
                {companies.error}
              </div>
            ) : null}
            {companies.savedAt && !companies.conflict ? (
              <div className="panel mb-4 border-l-4 border-l-green-600 px-5 py-3 text-sm text-green-700">
                Saved — everyone on the team now sees this version.
              </div>
            ) : null}
            {staleNotice ? (
              <div
                role="status"
                className="panel mb-4 flex flex-wrap items-center justify-between gap-3 border-l-4 border-l-amber-500 px-5 py-3 text-sm text-amber-700"
              >
                <span>
                  A teammate just saved a newer version. Your unsaved edits are kept — save to
                  publish yours, or load theirs.
                </span>
                <Button size="sm" variant="secondary" onClick={discardAndReload}>
                  Load their version
                </Button>
              </div>
            ) : null}

            {draft.length === 0 ? (
              <div className="panel p-10 text-center text-sm text-muted-foreground">
                No companies yet. Click <b>Add company</b> to start the sheet.
              </div>
            ) : filtered.length === 0 ? (
              <div className="panel p-10 text-center text-sm text-muted-foreground">
                No companies match <b>&ldquo;{search.trim()}&rdquo;</b>. Try a different name,
                state, or address.
              </div>
            ) : (
              <div className="space-y-5">
                {filtered.map((c, ci) => (
                  <CompanyCard
                    key={c.id}
                    company={c}
                    index={ci}
                    onRemove={() => removeCompany(c.id)}
                    onPatch={(patch) => setCompany(c.id, patch)}
                    onAddLocation={() => addLocation(c.id)}
                    onRemoveLocation={(locId) => removeLocation(c.id, locId)}
                    onPatchLocation={(locId, patch) => setLocation(c.id, locId, patch)}
                    onAddressBlur={(loc) => onAddressBlur(c.id, loc)}
                    onPickLocation={(locId) => {
                      const loc = c.locations.find((l) => l.id === locId);
                      setPinTarget({
                        companyId: c.id,
                        locId,
                        lat: loc?.lat ?? null,
                        lng: loc?.lng ?? null,
                      });
                    }}
                  />
                ))}
              </div>
            )}
          </>
        )}

        <p className="mt-6 flex items-center gap-1.5 text-xs text-muted-foreground">
          <ArrowLeft className="h-3.5 w-3.5" aria-hidden="true" />
          Edits here are saved to the shared store. Switch back to the heat map to see them on the
          map — it reloads the shared list automatically.
        </p>
      </main>

      {pinTarget ? (
        <GoogleLinkModal
          currentLabel={
            draft
              .find((c) => c.id === pinTarget.companyId)
              ?.locations.find((l) => l.id === pinTarget.locId)?.label ?? ""
          }
          currentLat={pinTarget.lat}
          currentLng={pinTarget.lng}
          onClose={() => setPinTarget(null)}
          onPick={(picked) => {
            applyPickedLocation(pinTarget.companyId, pinTarget.locId, picked);
            setPinTarget(null);
          }}
        />
      ) : null}
    </div>
  );
}

const inputCls =
  "w-full rounded-md border border-input bg-background px-2.5 py-1.5 text-sm text-foreground outline-none focus-visible:ring-2 focus-visible:ring-ring";
const labelCls = "mb-1 block text-xs font-semibold text-muted-foreground";
const cellCls = "min-w-0";

function CompanyCard({
  company,
  index,
  onRemove,
  onPatch,
  onAddLocation,
  onRemoveLocation,
  onPatchLocation,
  onAddressBlur,
  onPickLocation,
}: {
  company: Company;
  index: number;
  onRemove: () => void;
  onPatch: (patch: Partial<Company>) => void;
  onAddLocation: () => void;
  onRemoveLocation: (locId: string) => void;
  onPatchLocation: (locId: string, patch: Partial<CompanyLocation>) => void;
  onAddressBlur: (loc: CompanyLocation) => void;
  onPickLocation: (locId: string) => void;
}) {
  return (
    <section className="panel overflow-hidden" data-company-card>
      <div className="flex flex-wrap items-end justify-between gap-3 border-b border-border px-5 py-4">
        <div className="grid flex-1 grid-cols-1 gap-3 sm:grid-cols-3">
          <div className={cellCls + " sm:col-span-3"}>
            <label className={labelCls} htmlFor={`name-${company.id}`}>
              Company name
            </label>
            <input
              id={`name-${company.id}`}
              className={inputCls}
              value={company.name}
              placeholder={`Company #${index + 1}`}
              onChange={(e) => onPatch({ name: e.target.value })}
            />
          </div>
          <div className={cellCls}>
            <label className={labelCls} htmlFor={`team-${company.id}`}>
              Team
            </label>
            <select
              id={`team-${company.id}`}
              className={inputCls}
              value={company.team}
              onChange={(e) => onPatch({ team: e.target.value })}
            >
              <option value="">— Select —</option>
              {TEAMS.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </div>
          <div className={cellCls + " sm:col-span-2"}>
            <label className={labelCls} htmlFor={`sig-${company.id}`}>
              Signature status
            </label>
            <select
              id={`sig-${company.id}`}
              className={inputCls}
              value={company.signatureStatus}
              onChange={(e) => onPatch({ signatureStatus: e.target.value })}
            >
              <option value="">— Select —</option>
              {SIGNATURE_STATUSES.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>
        </div>
        <Button variant="secondary" size="sm" onClick={onRemove}>
          <Trash2 className="mr-1.5 h-4 w-4" aria-hidden="true" />
          Remove
        </Button>
      </div>

      <div className="px-5 py-4">
        <div className="mb-2 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-foreground">Office locations</h3>
          <Button variant="secondary" size="sm" onClick={onAddLocation}>
            <Plus className="mr-1.5 h-4 w-4" aria-hidden="true" />
            Add location
          </Button>
        </div>
        <div className="space-y-3">
          {company.locations.map((loc, li) => (
            <LocationRow
              key={loc.id}
              loc={loc}
              index={li}
              onRemove={() => onRemoveLocation(loc.id)}
              onPatch={(patch) => onPatchLocation(loc.id, patch)}
              onAddressBlur={() => onAddressBlur(loc)}
              onPick={() => onPickLocation(loc.id)}
            />
          ))}
        </div>
      </div>
    </section>
  );
}

function LocationRow({
  loc,
  index,
  onRemove,
  onPatch,
  onAddressBlur,
  onPick,
}: {
  loc: CompanyLocation;
  index: number;
  onRemove: () => void;
  onPatch: (patch: Partial<CompanyLocation>) => void;
  onAddressBlur: () => void;
  onPick: () => void;
}) {
  return (
    <div className="rounded-lg border border-border bg-muted/30 p-3">
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-12">
        <div className={cellCls + " sm:col-span-4"}>
          <label className={labelCls} htmlFor={`addr-${loc.id}`}>
            Office address
          </label>
          <input
            id={`addr-${loc.id}`}
            className={inputCls}
            value={loc.label}
            placeholder={`Location #${index + 1} — street, city, state, ZIP`}
            onChange={(e) => onPatch({ label: e.target.value })}
            onBlur={onAddressBlur}
          />
          <div className="mt-1 flex flex-wrap items-center gap-2">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={onPick}
              className="border-[#2266FF] text-[#9ec5fe] hover:bg-[#2266FF]/10"
            >
              <Link2 className="mr-1 h-3.5 w-3.5" aria-hidden="true" />
              Set from Google Maps
            </Button>
            {loc.label.trim() ? (
              <a
                href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(loc.label)}`}
                target="_blank"
                rel="noreferrer"
                className="text-xs font-medium text-[#9ec5fe] underline-offset-4 hover:underline"
              >
                View on Google Maps ↗
              </a>
            ) : null}
          </div>
        </div>
        <div className={cellCls + " sm:col-span-2"}>
          <label className={labelCls} htmlFor={`cov-${loc.id}`}>
            Coverage
          </label>
          <select
            id={`cov-${loc.id}`}
            className={inputCls}
            value={loc.coverage}
            onChange={(e) => onPatch({ coverage: e.target.value })}
          >
            {COVERAGE_OPTIONS.map((o) => (
              <option key={o.value} value={o.value}>
                {o.label}
              </option>
            ))}
          </select>
        </div>
        <div className={cellCls + " sm:col-span-2"}>
          <label className={labelCls} htmlFor={`den-${loc.id}`}>
            Density
          </label>
          <select
            id={`den-${loc.id}`}
            className={inputCls}
            value={loc.marketDensity}
            onChange={(e) => onPatch({ marketDensity: e.target.value })}
          >
            {DENSITY_OPTIONS.map((d) => (
              <option key={d} value={d}>
                {d}
              </option>
            ))}
          </select>
        </div>
        <div className={cellCls + " sm:col-span-2"}>
          <label className={labelCls} htmlFor={`st-${loc.id}`}>
            State
          </label>
          <select
            id={`st-${loc.id}`}
            className={inputCls}
            value={loc.state}
            onChange={(e) => onPatch({ state: e.target.value })}
          >
            {STATE_OPTIONS.map((s) => (
              <option key={s} value={s}>
                {s || "— Not set —"}
              </option>
            ))}
          </select>
        </div>
        <div className={cellCls + " flex items-end sm:col-span-2"}>
          <Button
            variant="destructive"
            size="sm"
            onClick={onRemove}
            aria-label="Delete address"
            title="Delete this address"
          >
            <Trash2 className="h-4 w-4" aria-hidden="true" />
            Delete address
          </Button>
        </div>

        <div className={cellCls + " sm:col-span-5"}>
          <span className={labelCls}>Campaign types</span>
          <div className="flex flex-wrap gap-x-4 gap-y-1.5">
            {CAMPAIGN_TYPES.map((ct) => {
              const checked = loc.campaignTypes.includes(ct);
              return (
                <label
                  key={ct}
                  className="flex items-center gap-1.5 text-xs font-medium text-foreground"
                >
                  <input
                    type="checkbox"
                    className="h-3.5 w-3.5"
                    checked={checked}
                    onChange={(e) => {
                      const next = e.target.checked
                        ? [...loc.campaignTypes, ct]
                        : loc.campaignTypes.filter((x) => x !== ct);
                      onPatch({
                        campaignTypes: next.length ? next : ["General"],
                      });
                    }}
                  />
                  {ct}
                </label>
              );
            })}
          </div>
        </div>
        <div className={cellCls + " sm:col-span-3"}>
          <label className={labelCls} htmlFor={`stat-${loc.id}`}>
            Status
          </label>
          <select
            id={`stat-${loc.id}`}
            className={inputCls}
            value={loc.coaching ? "coaching" : loc.markets ? "active" : "inactive"}
            onChange={(e) => {
              const v = e.target.value;
              onPatch({
                markets: v === "active",
                coaching: v === "coaching",
              });
            }}
          >
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
            <option value="coaching">Coaching</option>
          </select>
        </div>
        <div className={cellCls + " flex items-center gap-2 sm:col-span-4"}>
          <label className="flex items-center gap-1.5 text-xs font-medium text-foreground">
            <input
              type="checkbox"
              className="h-3.5 w-3.5"
              checked={loc.addressVerified}
              onChange={(e) => onPatch({ addressVerified: e.target.checked })}
            />
            Address verified
          </label>
        </div>
      </div>
    </div>
  );
}
